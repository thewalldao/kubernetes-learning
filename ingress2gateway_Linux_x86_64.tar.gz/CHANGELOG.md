# Changelog

## Table of Contents

- [v0.1.0](#v010)
- [v0.1.0-rc1](#v010-rc1)

## v0.1.0
The first official release of ingress2gateway.

### Notable changes since v0.1.0-rc1

### Feature

- [Kong Provider] Add support for converting the `konghq.com/plugins` ingress annotation to a list of `ExtensionRef` HTTPRoute filters. (#72, @mlavacca)

## v0.1.0-rc1
initial release candidate. 
